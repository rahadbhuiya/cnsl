"""
cnsl/parsers.py — Log-line parsers for auth.log and tcpdump output.

Design principles:
  - auth.log is the *primary* signal (precise, human-readable, reliable).
  - tcpdump is *secondary / hint* (noisy — used only for observability).
  - Each parser returns an Event or None; no side effects.
"""

from __future__ import annotations

import re
from typing import Optional

from .models import Event, EventKind, now



# IP address helpers


def _clean_ip(ip: str) -> str:
    """
    Normalize an IP address string:
      - Strip IPv6 mapped IPv4 prefix (::ffff:1.2.3.4 → 1.2.3.4)
      - Strip zone IDs (fe80::1%eth0 → fe80::1)
      - Strip surrounding brackets ([::1] → ::1)
    """
    ip = ip.strip().strip("[]")
    # IPv6-mapped IPv4: ::ffff:1.2.3.4
    if ip.lower().startswith("::ffff:"):
        candidate = ip[7:]
        if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', candidate):
            return candidate
    # Zone ID: fe80::1%eth0
    if "%" in ip:
        ip = ip.split("%")[0]
    return ip



# auth.log (sshd lines) — primary signal
#
# Modern OpenSSH (Kali, Debian 12+, Ubuntu 24+) splits into two processes:
#   sshd[PID]          — the listener / pre-auth dispatcher
#   sshd-session[PID]  — the per-connection session handler
# All auth events (Failed password, Accepted, PAM failures) now come from
# sshd-session[PID], so every regex must match BOTH variants.


_SSHD_PREFIX = r"sshd(?:-session)?\[\d+\]:\s+"

# "Failed password for invalid user <user> from <ip> port <p> ssh2"
# "Failed password for <user> from <ip> port <p> ssh2"
# "error: PAM: Authentication failure for <user> from <ip>"
# "authentication failure; ...rhost=<ip>  user=<user>"
_FAIL_RE = re.compile(
    _SSHD_PREFIX
    + r"(?:Failed password|authentication failure|Invalid user"
    r"|error: PAM: Authentication failure|"
    r"Connection closed by authenticating user)"
    r".*?(?:from|rhost=)\s*(?P<ip>[\da-fA-F\.:]+)",
    re.IGNORECASE,
)
_FAIL_USER_RE = re.compile(
    r"(?:for invalid user\s+(?P<u1>\S+))|(?:for\s+(?P<u2>\S+))",
    re.IGNORECASE,
)

# "Accepted password for <user> from <ip> port <p> ssh2"
# "Accepted publickey for <user> from <ip> port <p> ssh2"
_SUCCESS_RE = re.compile(
    _SSHD_PREFIX
    + r"Accepted\s+(?:password|publickey)\s+for\s+"
    r"(?P<user>\S+)\s+from\s+(?P<ip>[\da-fA-F\.:]+)",
    re.IGNORECASE,
)

# "session opened for user <user> by ..."  (secondary success signal)
_SESSION_RE = re.compile(
    _SSHD_PREFIX + r"pam_unix.*session opened for user\s+(?P<user>\S+)",
    re.IGNORECASE,
)


def parse_auth_event(line: str) -> Optional[Event]:
    """Parse one auth.log line.  Returns an Event or None."""
    s = line.strip()
    if "sshd" not in s.lower():
        return None

    # --- success first (more specific pattern) ---
    m = _SUCCESS_RE.search(s)
    if m:
        return Event(
            ts=now(), source="auth", kind=EventKind.SSH_SUCCESS,
            src_ip=_clean_ip(m.group("ip")), user=m.group("user"), raw=s,
        )

    # --- fail ---
    m = _FAIL_RE.search(s)
    if m:
        ip   = _clean_ip(m.group("ip"))
        user: Optional[str] = None
        mu   = _FAIL_USER_RE.search(s)
        if mu:
            user = mu.group("u1") or mu.group("u2")
            # Reject non-usernames that leaked from regex (e.g. "invalid", "password")
            if user and user.lower() in ("invalid", "password", "failed", "error", "user"):
                user = None
        return Event(
            ts=now(), source="auth", kind=EventKind.SSH_FAIL,
            src_ip=ip, user=user, raw=s,
        )

    return None



# tcpdump — secondary / hint signal


# "IP 192.168.0.5.445 > 192.168.0.10.53218: Flags ..."
_TCPDUMP_IP_RE = re.compile(
    r"IP6?\s+(?P<src>[\da-fA-F\.:]+?)(?:\.(?P<sp>\d+))?"
    r"\s+>\s+(?P<dst>[\da-fA-F\.:]+?)(?:\.(?P<dp>\d+))?[\s:]"
)


def parse_tcpdump_hint(line: str) -> Optional[Event]:
    """
    Parse one tcpdump output line.  Returns a NET_HINT Event or None.
    Conservative: only produce hints for known-suspicious / interesting traffic.
    """
    s     = line.strip()
    lower = s.lower()

    hint: Optional[str] = None

    if " arp" in lower or lower.startswith("arp,") or "who-has" in lower:
        hint = "DISCOVERY"
    elif ".mdns" in lower or " mdns" in lower or "_googlecast" in lower:
        hint = "DISCOVERY"
    elif " nbns" in lower or " netbios" in lower or " smb" in lower:
        hint = "ENUM_HINT"
    elif re.search(r"\.(445|139)\b", lower):
        hint = "ENUM_HINT"
    elif " tcp " in lower and ".22 " in lower:
        hint = "SSH_NET"

    if hint is None:
        return None

    m      = _TCPDUMP_IP_RE.search(s)
    src_ip = _clean_ip(m.group("src")) if m and m.group("src") else None
    dst_ip = _clean_ip(m.group("dst")) if m and m.group("dst") else None

    return Event(
        ts=now(), source="net", kind=EventKind.NET_HINT,
        src_ip=src_ip, dst_ip=dst_ip, raw=s, meta={"hint": hint},
    )